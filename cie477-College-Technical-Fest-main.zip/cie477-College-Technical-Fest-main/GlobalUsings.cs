global using cie477.Models;
global using cie477.Extensions;